Team 
- Nebye Berhe, berhe - Designated Submitter
- Sirak Radaa, radaa
- Glen Stewart, stewart1